package pl.pawel.linkshell.speechy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpeechyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpeechyApplication.class, args);
	}

}
